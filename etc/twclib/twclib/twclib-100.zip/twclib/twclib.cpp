// Tiny Windows Class LIBrary ... twclib.lib

#include "twclib.h"

int TWCVersion()
{
	return 100;
}
