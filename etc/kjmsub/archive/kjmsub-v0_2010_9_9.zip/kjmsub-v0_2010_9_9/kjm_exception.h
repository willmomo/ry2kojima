//=============================================================================
//
//	2010-09-09 r.kojima
//
//=============================================================================
#pragma once


#include "kjm_base.h"


namespace kjm {
	class systemException {
	public:
		systemException(DWORD code, const _tstring& message) : m_code(code), m_message(message) {};
		virtual ~systemException() {};

		// �G���[�R�[�h���擾
		DWORD getCode() { return m_code; };

		// �G���[���b�Z�[�W���擾
		_tstring getMessage() { return m_message; };

	private:
		DWORD m_code;
		_tstring m_message;

	private:
		systemException() {};
	};
};
