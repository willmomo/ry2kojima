//=============================================================================
//
//	2010-09-09 r.kojima
//
//=============================================================================
#pragma once


#if defined(UNICODE) && !defined(_UNICODE)
#define _UNICODE
#endif

#if defined(_UNICODE) && !defined(UNICODE)
#define UNICODE
#endif

#include <windows.h>
#include <tchar.h>
#include <shlwapi.h>
#pragma comment(lib, "shlwapi.lib")

#include <string>
#include <vector>
#include <iostream>
#include <sstream>


#if defined(UNICODE)
#define _tout	std::wcout
#else
#define _tout	std::cout
#endif


namespace kjm {
	typedef std::basic_string<TCHAR>		_tstring;
	typedef std::vector<_tstring>			_tstrings;
	typedef std::basic_ostringstream<TCHAR>	_tostringstream;
};
