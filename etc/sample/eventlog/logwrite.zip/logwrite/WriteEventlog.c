#include <windows.h>
#include <stdio.h>
#include "message.h"

void PrintErrorMessage(char *szFile, char *szFunction, int nLine);

void WriteEventlog(char *szSourceName, DWORD numMessage, char *szText) {
    HANDLE hEventLog;
	char *dame[] = {NULL};
	LONG dwMessage = (LONG)MSG_0000 + numMessage;

	dame[0] = szText;

    hEventLog = RegisterEventSource(NULL, szSourceName);
	if(hEventLog == NULL) {
		PrintErrorMessage(__FILE__, "RegisterEventSource", __LINE__);
		ExitProcess(1);
	}

    ReportEvent(
        hEventLog,
        EVENTLOG_INFORMATION_TYPE,   /* mes.mc��Severity�ƘA�����Ȃ� */
        0,
        dwMessage,
        NULL,
        1,
        0,
        dame,
        NULL);

    DeregisterEventSource(hEventLog);
}

