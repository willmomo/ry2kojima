#include <windows.h>
#include <stdio.h>

void AddEventSource(char *szSourceName, char *szProgramName, char *szDLLpath);
void WriteEventlog(char *szSourceName, DWORD dwMessage, char *szText);

void main(int argc, char *argv[])
{
	if (argc <= 3 ) {
		fprintf(stderr, "%s SourceName ID Message [DLLpath]\n", argv[0]);
		fprintf(stderr, "  to specify DLLpath, a new Event Source is created\n");
		ExitProcess(1);
	}

	if (argc == 5)
		AddEventSource(argv[1], argv[0], argv[4]);

	WriteEventlog(argv[1], atoi(argv[2]), argv[3]);

}
