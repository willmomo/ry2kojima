#include <windows.h>
#include <stdio.h>

void PrintErrorMessage(char *szFile, char *szFunction, int nLine);
void PrintErrorMessage2(int nError, char *szFile, char *szFunction, int nLine);

void AddEventSource(char *szSourceName, char *szFullPath, char *szDLLPath)
{
	HKEY hKey;
	DWORD dwExistKey;

    // Add your source name as a subkey under the Application 
    // key in the EventLog registry key. 
	{ 
		UCHAR szKey[1024] = "SYSTEM\\CurrentControlSet\\Services\\EventLog\\Application\\";
		LONG lnResult;

		strncat(szKey, szSourceName, strlen(szKey));

		lnResult = RegCreateKeyEx(HKEY_LOCAL_MACHINE, szKey, 0, 
			NULL, REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, NULL, &hKey, &dwExistKey);
		if (lnResult != ERROR_SUCCESS) {
			PrintErrorMessage2(lnResult, __FILE__, "RegCreateKeyEx", __LINE__);
			ExitProcess(1);
		}
	}

    /* Add the name to the EventMessageFile subkey */
	{
 	    if (RegSetValueEx(hKey,            // subkey handle 
            "EventMessageFile",       // value name 
            0,                        // must be zero 
            REG_EXPAND_SZ,            // value type 
            (LPBYTE) szDLLPath,           // pointer to value data 
            strlen(szDLLPath) + 1))       // length of value data 
		{
			PrintErrorMessage(__FILE__, "RegCreateKey#2", __LINE__);
			ExitProcess(1);
		}
	}

    /* Set the supported event types in the TypesSupported subkey. */
	{
		DWORD dwData = EVENTLOG_ERROR_TYPE | EVENTLOG_WARNING_TYPE | 
	        EVENTLOG_INFORMATION_TYPE; 
 
	    if (RegSetValueEx(hKey,      // subkey handle 
            "TypesSupported",  // value name 
            0,                 // must be zero 
            REG_DWORD,         // value type 
            (LPBYTE) &dwData,  // pointer to value data 
            sizeof(DWORD)))    // length of value data 
		{
			PrintErrorMessage(__FILE__, "RegCreateKey#3", __LINE__);
			ExitProcess(1);
		}
	}
 
    RegCloseKey(hKey); 
}
