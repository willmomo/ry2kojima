#include <windows.h>

void AddEventSource()
{
    HKEY hk; 
    DWORD dwData; 
    UCHAR szBuf[80]; 
 
    // Add your source name as a subkey under the Application 
    // key in the EventLog registry key. 
 
    if (RegCreateKey(HKEY_LOCAL_MACHINE, 
            "SYSTEM\\CurrentControlSet\\Services\\EventLog\\Application\\Test", &hk)) 
        ErrorExit("Could not create the registry key."); 
 
    // Set the name of the message file. 
 
    strcpy(szBuf, "%SystemRoot%\\System\\SamplApp.dll"); 
 
    // Add the name to the EventMessageFile subkey. 
 
    if (RegSetValueEx(hk,             // subkey handle 
            "EventMessageFile",       // value name 
            0,                        // must be zero 
            REG_EXPAND_SZ,            // value type 
            (LPBYTE) szBuf,           // pointer to value data 
            strlen(szBuf) + 1))       // length of value data 
        ErrorExit("Could not set the event message file."); 
 
    // Set the supported event types in the TypesSupported subkey. 
 
    dwData = EVENTLOG_ERROR_TYPE | EVENTLOG_WARNING_TYPE | 
        EVENTLOG_INFORMATION_TYPE; 
 
    if (RegSetValueEx(hk,      // subkey handle 
            "TypesSupported",  // value name 
            0,                 // must be zero 
            REG_DWORD,         // value type 
            (LPBYTE) &dwData,  // pointer to value data 
            sizeof(DWORD)))    // length of value data 
        ErrorExit("Could not set the supported types."); 
 
    RegCloseKey(hk); 
} 
