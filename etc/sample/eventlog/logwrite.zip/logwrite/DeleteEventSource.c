#include <windows.h>
#include <stdio.h>

void PrintErrorMessage(char *szFile, char *szFunction, int nLine);

void DeleteEventSource(char *szSourceName, char *szFullPath)
{
    // Add your source name as a subkey under the Application 
    // key in the EventLog registry key. 
	{ 
		UCHAR szKey[1024] = "SYSTEM\\CurrentControlSet\\Services\\EventLog\\Application\\";
		LONG lnResult;

		strncat(szKey, szSourceName, strlen(szKey));

			lnResult = RegDeleteKey(HKEY_LOCAL_MACHINE, szKey);
			if (lnResult != ERROR_SUCCESS) {
				LPVOID lpMsgBuf;
				FormatMessage(
					FORMAT_MESSAGE_ALLOCATE_BUFFER |
				    FORMAT_MESSAGE_FROM_SYSTEM |
				    FORMAT_MESSAGE_IGNORE_INSERTS,
					NULL,
					lnResult,
				    MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // ����̌���
					(LPTSTR) &lpMsgBuf,
					0,
				    NULL
			);
			fprintf(stderr, "%s:%s(%d): %s\n", __FILE__, "RegCreateKeyEx", __LINE__, lpMsgBuf);
			LocalFree(lpMsgBuf);
			ExitProcess(1);
		}
	}

}
