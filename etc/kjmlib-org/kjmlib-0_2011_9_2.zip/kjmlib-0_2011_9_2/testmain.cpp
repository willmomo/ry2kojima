#include "kjmlib.h"

kjm::cmdLine g_cl;

//-----------------------------------------------------------------------------
// �e�X�g
//-----------------------------------------------------------------------------
void doMain() {
	kjm::eventLog el;

	if (el.openEventLog(_T("System"))) {
		kjm::eventLogRecord rec;
		int cnt = 0;
		while (el.readEventLog(EVENTLOG_SEQUENTIAL_READ | EVENTLOG_BACKWARDS_READ, 0, rec)) {
			DWORD recNo = rec.RecordNumber();
			std::basic_string<TCHAR> srcName = rec.get_SourceName();
			std::basic_string<TCHAR> cmpName = rec.ComputerName();
			std::basic_string<TCHAR> eidText = rec.EventIDText();
			std::basic_string<TCHAR> ctgText = rec.EventCategoryText();

			if (!ctgText.empty()) {
				int bp = 0;
			}

			cnt++;
		}
		el.closeEventLog();
	}
}

//-----------------------------------------------------------------------------
// �v���O�����X�^�[�g
//-----------------------------------------------------------------------------
int WINAPI _tWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow) {
	int ver = _MSC_VER;

	//kjm::baseSocket::startup();
	//CoInitialize(NULL);

#if defined(UNICODE)
	g_cl.parse(__argc, __wargv);
#else
	g_cl.parse(__argc, __argv);
#endif

	doMain();

	//CoUninitialize();
	//kjm::baseSocket::cleanup();
	return 0;
}
