#include "kjmlib.h"

kjm::cmdLine g_cl;

//-----------------------------------------------------------------------------
// �e�X�g
//-----------------------------------------------------------------------------
void doMain() {

	kjm::_tstring strPath, strName;

	kjm::util::getFullPathName(kjm::_tstring(512, _T('x')), strPath, strName);
	kjm::util::getFullPathName(_T(""), strPath, strName);
	kjm::util::getFullPathName(_T("e:..\\..\\..\\out.txt"), strPath, strName);
	kjm::util::getFullPathName(_T("...\\out.txt"), strPath, strName);
	kjm::util::getFullPathName(_T("d:out.txt"), strPath, strName);
	kjm::util::getFullPathName(_T("e:out.txt"), strPath, strName);
	kjm::util::getFullPathName(_T("e:\\work\\out.txt"), strPath, strName);
	kjm::util::getFullPathName(_T("..\\out.txt"), strPath, strName);
	kjm::util::getFullPathName(_T("out.txt"), strPath, strName);
}

//-----------------------------------------------------------------------------
// �v���O�����X�^�[�g
//-----------------------------------------------------------------------------
int WINAPI _tWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPTSTR lpCmdLine, int nCmdShow) {
	int ver = _MSC_VER;

	//kjm::baseSocket::startup();
	//CoInitialize(NULL);

#if defined(UNICODE)
	g_cl.parse(__argc, __wargv);
#else
	g_cl.parse(__argc, __argv);
#endif

	try {
		doMain();
	} catch (kjm::kjmException e) {
		kjm::_tstring s = e.m_msg;
	}


	//CoUninitialize();
	//kjm::baseSocket::cleanup();
	return 0;
}
