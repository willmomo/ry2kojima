package jp.co.rkojima.SudokuSupport;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.graphics.Color;
import android.widget.Toast;

class MyDialog extends Dialog  implements android.view.View.OnClickListener {
	private DialogCallback m_callback;
	
	public ArrayList<Integer> m_candidates;
	
	// �R���X�g���N�^
	public MyDialog(Context context, DialogCallback callback) {
		super(context);
		
		setContentView(R.layout.my_dialog);
		
		// �_�C�A���O��80%���ɂ��鏈��
		//DisplayMetrics metrics = getContext().getResources().getDisplayMetrics();
		//int dialogWidth = (int) (metrics.widthPixels * 0.8);
		//WindowManager.LayoutParams lp = this.getWindow().getAttributes();
		//lp.width = dialogWidth;
		//this.getWindow().setAttributes(lp);
		
		// �����ꂽ���̏������L�q���郊�X�i�[��ݒ�
		((Button)this.findViewById(R.id.button1)).setOnClickListener(this);
		((Button)this.findViewById(R.id.button2)).setOnClickListener(this);
		((Button)this.findViewById(R.id.button3)).setOnClickListener(this);
		((Button)this.findViewById(R.id.button4)).setOnClickListener(this);
		((Button)this.findViewById(R.id.button5)).setOnClickListener(this);
		((Button)this.findViewById(R.id.button6)).setOnClickListener(this);
		((Button)this.findViewById(R.id.button7)).setOnClickListener(this);
		((Button)this.findViewById(R.id.button8)).setOnClickListener(this);
		((Button)this.findViewById(R.id.button9)).setOnClickListener(this);
		((Button)this.findViewById(R.id.cancel)).setOnClickListener(this);
		this.m_callback = callback;
		
	}

	@Override
	public void onStart() {
		super.onStart();
		
		int[] ids = {R.id.button1, R.id.button2, R.id.button3,
					 R.id.button4, R.id.button5, R.id.button6,
					 R.id.button7, R.id.button8, R.id.button9,
					 R.id.cancel};
		
		for (int num = 1; num <= 9; num++) {
			Button btn = (Button)this.findViewById(ids[num - 1]);
			if (m_candidates.indexOf(num) == -1) {
				btn.setEnabled(false);
			} else {
				btn.setEnabled(true);
			}
		}
	}
	
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.button1:
	    	this.m_callback.onDialogOK(1, "1");
			break;
		case R.id.button2:
			this.m_callback.onDialogOK(2, "2");
			break;
		case R.id.button3:
			this.m_callback.onDialogOK(3, "3");
			break;
		case R.id.button4:
			this.m_callback.onDialogOK(4, "4");
			break;
		case R.id.button5:
			this.m_callback.onDialogOK(5, "5");
			break;
		case R.id.button6:
			this.m_callback.onDialogOK(6, "6");
			break;
		case R.id.button7:
			this.m_callback.onDialogOK(7, "7");
			break;
		case R.id.button8:
			this.m_callback.onDialogOK(8, "8");
			break;
		case R.id.button9:
			this.m_callback.onDialogOK(9, "9");
			break;
		}
    	this.dismiss();
	}
}

public class SudokuSupportActivity extends Activity implements DialogCallback {
	private MyDialog m_myDlg;
	private SudokuGame m_sudokuGame = new SudokuGame();
	private ArrayList<Integer> m_id = new ArrayList<Integer>();
	private int m_row = 0;
	private int m_col = 0;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        initID();
        
        TextView v = (TextView)findViewById(R.id.textViewR1C1);
        registerForContextMenu(v);

    	m_myDlg = new MyDialog(this, this);

    	this.m_sudokuGame.init();
    	drawAll();
    }

    // Activity�������Ɉ�x�����Ă΂��֐�
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
    	boolean ret = super.onCreateOptionsMenu(menu);
    	menu.add(0, Menu.FIRST, Menu.NONE, "������");
    	menu.add(1, Menu.FIRST + 1, Menu.NONE, "��߂�");
    	menu.add(2, Menu.FIRST + 2, Menu.NONE, "�Z�[�u");
    	menu.add(3, Menu.FIRST + 3, Menu.NONE, "���[�h");
    	menu.add(4, Menu.FIRST + 4, Menu.NONE, "����");
    	return ret;
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
    	switch (item.getItemId()) {
    	case Menu.FIRST:
    		this.m_sudokuGame.init();
    		this.drawAll();
    		break;
    	case Menu.FIRST + 1:
    		this.m_sudokuGame.popBoard();
    		this.drawAll();
    		break;
    	case Menu.FIRST + 2:
    		try {
				saveGame();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		break;
    	case Menu.FIRST + 3:
    		try {
				loadGame();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		break;
    	case Menu.FIRST + 4:
    		doAll();
    		break;
    	}
    	return super.onOptionsItemSelected(item);
    }
    
    private void saveGame() throws IOException {
    	// �X�g���[�����J��
    	FileOutputStream output = this.openFileOutput("sudoku.dat", MODE_PRIVATE);
    	
    	// ���Ƃ̏�Ԃ���������
    	for (int row = 0; row < this.m_sudokuGame.getBoard().blockCellCound(); row++) {
    		for (int col = 0; col < this.m_sudokuGame.getBoard().blockCellCound(); col++) {
    			if (!(row == 0 && col == 0)) {
    				output.write(",".getBytes());
    			}
    			output.write(String.valueOf(this.m_sudokuGame.getBoard().cells().get(row).get(col).getNumber()).getBytes());
    		}
    	}
    	
    	// �X�g���[�������
    	output.close();
    }
    
    private void loadGame() throws IOException {
    	// �X�g���[�����J��
    	FileInputStream input = this.openFileInput("sudoku.dat");
    	
    	// �Ǎ���
    	BufferedReader reader = new BufferedReader(new InputStreamReader(input));
    	String line = reader.readLine();
    	reader.close();
    	
    	this.m_sudokuGame.init();
    	
    	String[] nums = line.split(",");
    	for (int i = 0; i < nums.length; i++) {
    		int row = i / 9;
    		int col = i % 9;
    		this.m_sudokuGame.getBoard().fixNumber(row, col, Integer.parseInt(nums[i]));
    	}
    	
    	drawAll();
    }

    private void doAll() {
		while (
				m_sudokuGame.parse00() ||
				m_sudokuGame.parse01() ||
				m_sudokuGame.parse02() ||
				m_sudokuGame.parse03() ||
				m_sudokuGame.parse12() ||
				m_sudokuGame.parse30())
				;
				
			drawAll();
			
			String msg = "�N���A�ł��܂���";
			if (m_sudokuGame.getBoard().isFinished()) {
				msg = "�N���A";
			}
			
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setTitle("���ƃT�|�[�g").setMessage(msg).setPositiveButton("OK", null).show();
    }
	public void drawAll() {
		for (int row = 0; row < 9; row++) {
			for (int col = 0; col < 9; col++) {
				TextView elem = (TextView) this.findViewById(m_id.get(row * 9 + col));
				
				//SudokuBoard sb = this.m_sudokuGame.getBoard();
				//ArrayList<ArrayList<SudokuCell>> cells = sb.cells();
				//ArrayList<SudokuCell> rows = cells.get(row);
				
				int num = this.m_sudokuGame.getBoard().cells().get(row).get(col).getNumber();
				if (num == 0) {
					//elem.setText("-");
					String text = "";
					ArrayList<Integer> candidates = this.m_sudokuGame.getBoard().cells().get(row).get(col).getCandidates();
					if (candidates.size() > 2) {
						text = "+";
						elem.setTextAppearance(this, android.R.style.TextAppearance_Large);
					} else {
						for (int i = 0; i < candidates.size(); i++) {
							text += String.valueOf(candidates.get(i));
						}
						elem.setTextAppearance(this, android.R.style.TextAppearance_Small);
					}
					elem.setText(text);
					elem.setTextColor(Color.DKGRAY);
					//elem.setTextSize(15);
				} else {
					elem.setTextAppearance(this, android.R.style.TextAppearance_Large);
					elem.setText(String.valueOf(num));
					elem.setTextColor(Color.WHITE);
					//elem.setTextSize(20);
				}
			}
		}
	}
	
    public void onDialogOK(int id, String value) {
    	this.m_sudokuGame.pushBoard();
    	this.m_sudokuGame.getBoard().fixNumber(m_row - 1, m_col - 1, id);
    	this.drawAll();
    }

	private void onClickRxCx(int row, int col) {
		m_row = row;
		m_col = col;
		
		if (this.m_sudokuGame.getBoard().cells().get(row - 1).get(col - 1).getNumber() == 0) {
			String itemCsv = this.m_sudokuGame.getBoard().cells().get(row - 1).get(col - 1).getCandidates().toString();
			itemCsv = itemCsv.replaceAll("\\[|\\]", "");
			itemCsv = itemCsv.replaceAll(" ", "");
			final String[] items = itemCsv.split(",");
			
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setIcon(R.drawable.ic_launcher);
			builder.setTitle("���l�I��");
			builder.setItems(items, new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					// TODO Auto-generated method stub
					//Toast.makeText(SudokuSupportActivity.this, "select=" + items[which], 2000).show();
	
					SudokuSupportActivity.this.m_sudokuGame.pushBoard();
					SudokuSupportActivity.this.m_sudokuGame.getBoard().fixNumber(m_row - 1, m_col - 1, 
							Integer.parseInt(items[which]));
					SudokuSupportActivity.this.drawAll();
				}
			});
			builder.show();
		}
		/*
		m_row = row;
		m_col = col;
    	m_myDlg.m_candidates = this.m_sudokuGame.getBoard().cells().get(m_row - 1).get(m_col - 1).getCandidates();
    	m_myDlg.show();
    	*/
	}
    
	public void onClickRnCn(View v) {
    	String[] contents = v.getContentDescription().toString().split(",");
    	onClickRxCx(Integer.valueOf(contents[0]), Integer.valueOf(contents[1]));
	}
    
    public void initID() {
        m_id.add(R.id.textViewR1C1);
        m_id.add(R.id.textViewR1C2);
        m_id.add(R.id.textViewR1C3);
        m_id.add(R.id.textViewR1C4);
        m_id.add(R.id.textViewR1C5);
        m_id.add(R.id.textViewR1C6);
        m_id.add(R.id.textViewR1C7);
        m_id.add(R.id.textViewR1C8);
        m_id.add(R.id.textViewR1C9);

        m_id.add(R.id.textViewR2C1);
        m_id.add(R.id.textViewR2C2);
        m_id.add(R.id.textViewR2C3);
        m_id.add(R.id.textViewR2C4);
        m_id.add(R.id.textViewR2C5);
        m_id.add(R.id.textViewR2C6);
        m_id.add(R.id.textViewR2C7);
        m_id.add(R.id.textViewR2C8);
        m_id.add(R.id.textViewR2C9);

        m_id.add(R.id.textViewR3C1);
        m_id.add(R.id.textViewR3C2);
        m_id.add(R.id.textViewR3C3);
        m_id.add(R.id.textViewR3C4);
        m_id.add(R.id.textViewR3C5);
        m_id.add(R.id.textViewR3C6);
        m_id.add(R.id.textViewR3C7);
        m_id.add(R.id.textViewR3C8);
        m_id.add(R.id.textViewR3C9);

        m_id.add(R.id.textViewR4C1);
        m_id.add(R.id.textViewR4C2);
        m_id.add(R.id.textViewR4C3);
        m_id.add(R.id.textViewR4C4);
        m_id.add(R.id.textViewR4C5);
        m_id.add(R.id.textViewR4C6);
        m_id.add(R.id.textViewR4C7);
        m_id.add(R.id.textViewR4C8);
        m_id.add(R.id.textViewR4C9);

        m_id.add(R.id.textViewR5C1);
        m_id.add(R.id.textViewR5C2);
        m_id.add(R.id.textViewR5C3);
        m_id.add(R.id.textViewR5C4);
        m_id.add(R.id.textViewR5C5);
        m_id.add(R.id.textViewR5C6);
        m_id.add(R.id.textViewR5C7);
        m_id.add(R.id.textViewR5C8);
        m_id.add(R.id.textViewR5C9);

        m_id.add(R.id.textViewR6C1);
        m_id.add(R.id.textViewR6C2);
        m_id.add(R.id.textViewR6C3);
        m_id.add(R.id.textViewR6C4);
        m_id.add(R.id.textViewR6C5);
        m_id.add(R.id.textViewR6C6);
        m_id.add(R.id.textViewR6C7);
        m_id.add(R.id.textViewR6C8);
        m_id.add(R.id.textViewR6C9);

        m_id.add(R.id.textViewR7C1);
        m_id.add(R.id.textViewR7C2);
        m_id.add(R.id.textViewR7C3);
        m_id.add(R.id.textViewR7C4);
        m_id.add(R.id.textViewR7C5);
        m_id.add(R.id.textViewR7C6);
        m_id.add(R.id.textViewR7C7);
        m_id.add(R.id.textViewR7C8);
        m_id.add(R.id.textViewR7C9);

        m_id.add(R.id.textViewR8C1);
        m_id.add(R.id.textViewR8C2);
        m_id.add(R.id.textViewR8C3);
        m_id.add(R.id.textViewR8C4);
        m_id.add(R.id.textViewR8C5);
        m_id.add(R.id.textViewR8C6);
        m_id.add(R.id.textViewR8C7);
        m_id.add(R.id.textViewR8C8);
        m_id.add(R.id.textViewR8C9);

        m_id.add(R.id.textViewR9C1);
        m_id.add(R.id.textViewR9C2);
        m_id.add(R.id.textViewR9C3);
        m_id.add(R.id.textViewR9C4);
        m_id.add(R.id.textViewR9C5);
        m_id.add(R.id.textViewR9C6);
        m_id.add(R.id.textViewR9C7);
        m_id.add(R.id.textViewR9C8);
        m_id.add(R.id.textViewR9C9);
    }
}

interface DialogCallback {
	public void onDialogOK(int id, String value);
}
