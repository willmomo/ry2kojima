package jp.co.rkojima.SudokuSupport;

import java.util.ArrayList;;

public class SudokuCell {
	private int m_number;
	private ArrayList<Integer> m_candidates = new ArrayList<Integer>();
	
	public SudokuCell() {
		
	}
	
	public int getNumber() {
		return m_number;
	}
	
	public void setNumber(int newValue) {
		m_number = newValue;
	}

	public ArrayList<Integer> getCandidates() {
		return this.m_candidates;
	}
	
	public SudokuCell clone() {
		SudokuCell cpy = new SudokuCell();
		cpy.m_number = this.m_number;
		cpy.m_candidates = (ArrayList<Integer>) this.m_candidates.clone();
		return cpy;
	}
	public SudokuCell(int blockCellCount) {
		for (int i = 0; i < blockCellCount; i++) {
			this.m_candidates.add(i + 1);
		}
	}
	
	public void fixNumber_(int number_) {
		this.m_number = number_;
		this.m_candidates.clear();
	}
	
	public void removeCandidate(int number_) {
		int index = this.m_candidates.indexOf(number_);
		if (index >= 0) {
			this.m_candidates.remove(index);
		}
	}
}
