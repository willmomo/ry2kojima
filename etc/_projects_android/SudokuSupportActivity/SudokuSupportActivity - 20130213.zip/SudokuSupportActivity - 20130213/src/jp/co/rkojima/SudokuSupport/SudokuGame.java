package jp.co.rkojima.SudokuSupport;

import java.util.ArrayList;

public class SudokuGame {
	private int m_baseNum;
	private ArrayList<SudokuBoard> m_boardStack;
	private SudokuBoard m_board;
	
	public SudokuBoard getBoard() {
		return this.m_board;
	}
	
	public SudokuGame() {
		m_baseNum = 3;
		m_boardStack = new ArrayList<SudokuBoard>();
		m_board = new SudokuBoard(m_baseNum);
	}
	
	public void pushBoard() {
		m_boardStack.add(0, m_board.clone());
	}
	
	public void popBoard() {
		m_board = m_boardStack.get(0);
		m_boardStack.remove(0);
	}
	
	public int blockCellCount() {
		return this.m_baseNum * this.m_baseNum;
	}
	
	public void init() {
		this.m_board.init();
		this.m_boardStack.clear();
	}

	// ��₪�ЂƂ����Ȃ��Z�����m�肷��
	public boolean parse00() {
		for (int row = 0; row < this.blockCellCount(); row++) {
			for (int col = 0; col < this.blockCellCount(); col++) {
				if (this.m_board.cells().get(row).get(col).getCandidates().size() == 1) {
					this.m_board.fixNumber(row, col, this.m_board.cells().get(row).get(col).getCandidates().get(0));
					return true;
				}
			}
		}
		return false;
	}

	// �������O���[�v���ŁA��₪�ЂƂ����Ȃ��������m�肳����
	public boolean parse01() {
		for (int row = 0; row < this.blockCellCount(); row++) {
			for (int num = 1; num <= this.blockCellCount(); num++) {
				int cnt = 0;
				int foundCol = 0;
				for (int col = 0; col < this.blockCellCount(); col++) {
					if (this.m_board.cells().get(row).get(col).getCandidates().indexOf(num) >= 0) {
						cnt++;
						foundCol = col;
					}
				}
				
				if (cnt == 1) {
					this.m_board.fixNumber(row, foundCol, num);
					return true;
				}
			}
		}
		return false;
	}

	// �������O���[�v���ŁA��₪�ЂƂ����Ȃ��������m�肳����
	public boolean parse02() {
		for (int col = 0; col < this.blockCellCount(); col++) {
			for (int num = 1; num <= this.blockCellCount(); num++) {
				int cnt = 0;
				int foundRow = 0;
				for (int row = 0; row < this.blockCellCount(); row++) {
					if (this.m_board.cells().get(row).get(col).getCandidates().indexOf(num) >= 0) {
						cnt++;
						foundRow = row;
					}
				}
				
				if (cnt == 1) {
					this.m_board.fixNumber(foundRow, col, num);
					return true;
				}
			}
		}
		return false;
	}
	
	// �u���b�N�O���[�v���ŁA��₪�ЂƂ����Ȃ��������m�肳����
	public boolean parse03() {
		for (int blk = 0; blk < this.blockCellCount(); blk++) {
			for (int num = 0; num <= this.blockCellCount(); num++) {
				int cnt = 0;
				int foundRow = 0;
				int foundCol = 0;
				for (int row = (int) (Math.floor(blk / this.m_baseNum) * this.m_baseNum); row < Math.floor(blk / this.m_baseNum) * this.m_baseNum + this.m_baseNum; row++) {
					for (int col = (blk % this.m_baseNum) * this.m_baseNum; col < (blk % this.m_baseNum) * this.m_baseNum + this.m_baseNum; col++) {
						if (this.m_board.cells().get(row).get(col).getCandidates().indexOf(num) >= 0) {
							cnt++;
							foundRow = row;
							foundCol = col;
						}
					}
				}
				
				if (cnt == 1) {
					this.m_board.fixNumber(foundRow, foundCol, num);
					return true;
				}
			}
		}
		return false;
	}

	// �u���b�N���Ō�₪������Ȃ��Arow�܂���col�����ɕ���ł���ꍇ
	// ���u���b�N�� row �܂��� col ����A�폜����
	private int countNumInBlock(int blk, int num, ArrayList<Integer> rowList, ArrayList<Integer> colList) {
		int count = 0;
		
		for (int row = (int) (Math.floor(blk / this.m_baseNum) * this.m_baseNum); row < Math.floor(blk / this.m_baseNum) * this.m_baseNum + this.m_baseNum; row++) {
			for (int col = (blk % this.m_baseNum) * this.m_baseNum; col < (blk % this.m_baseNum) * this.m_baseNum + this.m_baseNum; col++) {
				if (this.m_board.cells().get(row).get(col).getCandidates().indexOf(num) >= 0) {
					++count;
					rowList.add(row);
					colList.add(col);
				}
			}
		}
		return count;
	}

	private boolean sameAll(ArrayList<Integer> ar) {
		if (ar.size() <= 1) {
			return true;
		}
		for (int i = 1; i < ar.size(); i++) {
			if (ar.get(0) != ar.get(i)) {
				return false;
			}
		}
		return true;
	}
	
	public boolean parse12() {
		boolean result = false;
		
		for (int blk = 0; blk < this.blockCellCount(); blk++) {
			for (int num = 1; num <= this.blockCellCount(); num++) {
				ArrayList<Integer> rowList = new ArrayList<Integer>();
				ArrayList<Integer> colList = new ArrayList<Integer>();
				int count = this.countNumInBlock(blk, num, rowList, colList);
				
				if (count == 2 || count == 3) {
					if (sameAll(rowList)) {
						for (int col = 0; col < this.blockCellCount(); col++) {
							if (colList.indexOf(col) == -1) {
								if (this.m_board.cells().get(rowList.get(0)).get(col).getCandidates().indexOf(num) >= 0) {
									this.m_board.cells().get(rowList.get(0)).get(col).removeCandidate(num);
									result = true;
								}
							}
						}
					} else if (sameAll(colList)) {
						for (int row = 0; row < this.blockCellCount(); row++) {
							if (rowList.indexOf(row) == -1) {
								if (this.m_board.cells().get(row).get(colList.get(0)).getCandidates().indexOf(num) >= 0) {
									this.m_board.cells().get(row).get(colList.get(0)).removeCandidate(num);
									result = true;
								}
							}
						}
					} else {
					}
				}
			}
		}
		
		return result;
	}

	// ���m��Z����������Ȃ��u���b�N��T��
	public ArrayList<Integer> findBlock() {
		int r1 = 0, c1 = 0, r2 = 0, c2 = 0;
		for (int blk = 0; blk < this.blockCellCount(); blk++) {
			int count = 0;
			for (int row = (int) (Math.floor(blk / this.m_baseNum) * this.m_baseNum); row < Math.floor(blk / this.m_baseNum) * this.m_baseNum + this.m_baseNum; row++) {
				for (int col = (blk % this.m_baseNum) * this.m_baseNum; col < (blk % this.m_baseNum) * this.m_baseNum + this.m_baseNum; col++) {
					if (this.m_board.cells().get(row).get(col).getNumber() == 0) {
						if (count == 0) {
							r1 = row;
							c1 = col;
							++count;
						} else if (count == 1) {
							r2 = row;
							c2 = col;
							++count;
						} else {
							++count;
							break;
						}
					}
				}
			}
			if (count == 2) {
				ArrayList<Integer> result = new ArrayList<Integer>();
				result.add(blk);
				result.add(r1);
				result.add(c1);
				result.add(r2);
				result.add(c2);
				return result;
			}
		}
		ArrayList<Integer> result = new ArrayList<Integer>();
		result.add(-1);
		result.add(r1);
		result.add(c1);
		result.add(r2);
		result.add(c2);
		return result;
	}

	// ���m��Z����������Ȃ��u���b�N�́A
	// ����������Ȃ��A�ǂ��炩�͕K�������ł���͂�������A
	// �Q�[���𕡐����āA�G���[��ԂɂȂ�Ȃ����`�F�b�N����B
	public boolean parse30() {
		ArrayList<Integer> ret = this.findBlock();
		int blk = ret.get(0);
		int r1 = ret.get(1);
		int c1 = ret.get(2);
		//int r2 = ret.get(3);
		//int c2 = ret.get(4);

		if (blk >= 0) {
			SudokuGame tempGame = new SudokuGame();
			tempGame.m_board = this.m_board.clone();

			tempGame.m_board.fixNumber(r1, c1, tempGame.m_board.cells().get(r1).get(c1).getCandidates().get(0));

			while (
				tempGame.parse00() ||
				tempGame.parse01() ||
				tempGame.parse02() ||
				tempGame.parse03() ||
				tempGame.parse12())
				;

			if (tempGame.m_board.isFinished()) {
				this.m_board.fixNumber(r1, c1, this.m_board.cells().get(r1).get(c1).getCandidates().get(0));
				return true;
			} else if (tempGame.m_board.isFailed()) {
				this.m_board.cells().get(r1).get(c1).removeCandidate(this.m_board.cells().get(r1).get(c1).getCandidates().get(0));
				return true;
			} else {
				return false;
			}
		}
		return false;
	}
}
