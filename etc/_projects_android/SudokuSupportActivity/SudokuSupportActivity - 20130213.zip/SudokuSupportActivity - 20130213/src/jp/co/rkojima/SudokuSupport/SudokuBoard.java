package jp.co.rkojima.SudokuSupport;

import java.util.ArrayList;

public class SudokuBoard {
	private int m_baseNum;
	private ArrayList<ArrayList<SudokuCell>> m_cells = new ArrayList<ArrayList<SudokuCell>>();

	public SudokuBoard() {
		this.m_baseNum = 3;
	}
	
	public SudokuBoard(int baseNumber) {
		this.m_baseNum = baseNumber;
	}

	public SudokuBoard clone() {
		SudokuBoard cpy = new SudokuBoard();
		cpy.m_baseNum = this.m_baseNum;
		//cpy.m_cells = (ArrayList<ArrayList<SudokuCell>>) this.m_cells.clone();
		for (int row = 0; row < blockCellCound(); row++) {
			cpy.m_cells.add(new ArrayList<SudokuCell>());
			for (int col = 0; col < blockCellCound(); col++) {
				cpy.m_cells.get(row).add(this.m_cells.get(row).get(col).clone());
			}
		}
		return cpy;
	}
	
	public ArrayList<ArrayList<SudokuCell>> cells() {
		return m_cells;
	}
	
	public int blockCellCound() {
		return this.m_baseNum * this.m_baseNum;
	}
	
	public void init() {
		this.m_cells.clear();
		for (int row = 0; row < this.blockCellCound(); row++) {
			this.m_cells.add(new ArrayList<SudokuCell>());
			for (int col = 0; col < this.blockCellCound(); col++) {
				this.m_cells.get(row).add(new SudokuCell(this.blockCellCound()));
			}
		}
	}
	
	public boolean isFinished() {
		for (int row = 0; row < this.blockCellCound(); row++) {
			for (int col = 0; col < this.blockCellCound(); col++) {
				if (this.m_cells.get(row).get(col).getNumber() == 0) {
					return false;
				}
			}
		}
		return true;
	}
	
	public boolean isFailed() {
		for (int row = 0; row < this.blockCellCound(); row++) {
			for (int col = 0; col < this.blockCellCound(); col++) {
				if (this.m_cells.get(row).get(col).getNumber() == 0 && 
					this.m_cells.get(row).get(col).getCandidates().size() == 0) {
					return true;
				}
			}
		}
		return false;
	}
	
	public void fixNumber(int rrr, int ccc, int num) {
		if (this.m_cells.get(rrr).get(ccc).getCandidates().indexOf(num) == -1) {
			return;
		}
		
		this.m_cells.get(rrr).get(ccc).fixNumber_(num);
		
		for (int col = 0; col < this.blockCellCound(); col++) {
			this.m_cells.get(rrr).get(col).removeCandidate(num);
		}
		
		for (int row = 0; row < this.blockCellCound(); row++) {
			this.m_cells.get(row).get(ccc).removeCandidate(num);
		}
		
		int row_top = (int) Math.floor(rrr / this.m_baseNum) * this.m_baseNum;
		int col_top = (int) Math.floor(ccc / this.m_baseNum) * this.m_baseNum;
		for (int row = row_top; row < row_top + this.m_baseNum; row++) {
			for (int col = col_top; col < col_top + this.m_baseNum; col++) {
				this.m_cells.get(row).get(col).removeCandidate(num);
			}
		}
	}
}
