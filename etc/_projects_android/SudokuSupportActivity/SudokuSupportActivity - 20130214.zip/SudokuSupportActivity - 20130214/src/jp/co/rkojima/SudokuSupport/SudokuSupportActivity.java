package jp.co.rkojima.SudokuSupport;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.graphics.Color;


public class SudokuSupportActivity extends Activity {
	private SudokuGame m_sudokuGame = new SudokuGame();
	private ArrayList<Integer> m_id = new ArrayList<Integer>();
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        this.initID();
        
        //TextView v = (TextView)findViewById(R.id.textViewR1C1);
        //registerForContextMenu(v);

    	this.m_sudokuGame.init();
    	this.drawAll();
    }
    
	/** 81����TextView�ɃA�N�Z�X��ׂ̃��X�g�������� */
    private void initID() {
        m_id.add(R.id.textViewR1C1);
        m_id.add(R.id.textViewR1C2);
        m_id.add(R.id.textViewR1C3);
        m_id.add(R.id.textViewR1C4);
        m_id.add(R.id.textViewR1C5);
        m_id.add(R.id.textViewR1C6);
        m_id.add(R.id.textViewR1C7);
        m_id.add(R.id.textViewR1C8);
        m_id.add(R.id.textViewR1C9);

        m_id.add(R.id.textViewR2C1);
        m_id.add(R.id.textViewR2C2);
        m_id.add(R.id.textViewR2C3);
        m_id.add(R.id.textViewR2C4);
        m_id.add(R.id.textViewR2C5);
        m_id.add(R.id.textViewR2C6);
        m_id.add(R.id.textViewR2C7);
        m_id.add(R.id.textViewR2C8);
        m_id.add(R.id.textViewR2C9);

        m_id.add(R.id.textViewR3C1);
        m_id.add(R.id.textViewR3C2);
        m_id.add(R.id.textViewR3C3);
        m_id.add(R.id.textViewR3C4);
        m_id.add(R.id.textViewR3C5);
        m_id.add(R.id.textViewR3C6);
        m_id.add(R.id.textViewR3C7);
        m_id.add(R.id.textViewR3C8);
        m_id.add(R.id.textViewR3C9);

        m_id.add(R.id.textViewR4C1);
        m_id.add(R.id.textViewR4C2);
        m_id.add(R.id.textViewR4C3);
        m_id.add(R.id.textViewR4C4);
        m_id.add(R.id.textViewR4C5);
        m_id.add(R.id.textViewR4C6);
        m_id.add(R.id.textViewR4C7);
        m_id.add(R.id.textViewR4C8);
        m_id.add(R.id.textViewR4C9);

        m_id.add(R.id.textViewR5C1);
        m_id.add(R.id.textViewR5C2);
        m_id.add(R.id.textViewR5C3);
        m_id.add(R.id.textViewR5C4);
        m_id.add(R.id.textViewR5C5);
        m_id.add(R.id.textViewR5C6);
        m_id.add(R.id.textViewR5C7);
        m_id.add(R.id.textViewR5C8);
        m_id.add(R.id.textViewR5C9);

        m_id.add(R.id.textViewR6C1);
        m_id.add(R.id.textViewR6C2);
        m_id.add(R.id.textViewR6C3);
        m_id.add(R.id.textViewR6C4);
        m_id.add(R.id.textViewR6C5);
        m_id.add(R.id.textViewR6C6);
        m_id.add(R.id.textViewR6C7);
        m_id.add(R.id.textViewR6C8);
        m_id.add(R.id.textViewR6C9);

        m_id.add(R.id.textViewR7C1);
        m_id.add(R.id.textViewR7C2);
        m_id.add(R.id.textViewR7C3);
        m_id.add(R.id.textViewR7C4);
        m_id.add(R.id.textViewR7C5);
        m_id.add(R.id.textViewR7C6);
        m_id.add(R.id.textViewR7C7);
        m_id.add(R.id.textViewR7C8);
        m_id.add(R.id.textViewR7C9);

        m_id.add(R.id.textViewR8C1);
        m_id.add(R.id.textViewR8C2);
        m_id.add(R.id.textViewR8C3);
        m_id.add(R.id.textViewR8C4);
        m_id.add(R.id.textViewR8C5);
        m_id.add(R.id.textViewR8C6);
        m_id.add(R.id.textViewR8C7);
        m_id.add(R.id.textViewR8C8);
        m_id.add(R.id.textViewR8C9);

        m_id.add(R.id.textViewR9C1);
        m_id.add(R.id.textViewR9C2);
        m_id.add(R.id.textViewR9C3);
        m_id.add(R.id.textViewR9C4);
        m_id.add(R.id.textViewR9C5);
        m_id.add(R.id.textViewR9C6);
        m_id.add(R.id.textViewR9C7);
        m_id.add(R.id.textViewR9C8);
        m_id.add(R.id.textViewR9C9);
    }

    /**
     * Activity�������Ɉ�x�����Ă΂��֐�
     * ���\�[�X(res/menu/optionsmenu.xml)���g���āA���j���[�𐶐��B
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
    	Log.d("SS", "onCreateOptionsMenu");

    	this.getMenuInflater().inflate(R.menu.optionsmenu, menu);
    	
    	return super.onCreateOptionsMenu(menu);
    }
    
    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
    	Log.d("SS", "onPrepareOptionsMenu");
    	
    	menu.findItem(R.id.menuItem2).setEnabled(
    			this.m_sudokuGame.getBoardCount() == 0 ? false : true);
    	
    	return super.onPrepareOptionsMenu(menu);
    }
    
    /** ���j���[���ڂ�I�������Ƃ��̏��� */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
    	switch (item.getItemId()) {
    	case R.id.menuItem1:
    		this.m_sudokuGame.init();
    		this.drawAll();
    		break;
    	case R.id.menuItem2:
    		this.m_sudokuGame.popBoard();
    		this.drawAll();
    		break;
    	case R.id.menuItem3:
    		try {
				this.saveGame();
			} catch (IOException e) {
				e.printStackTrace();
			}
    		break;
    	case R.id.menuItem4:
			this.m_sudokuGame.pushBoard();
    		try {
    			this.loadGame();
			} catch (IOException e) {
				e.printStackTrace();
			}
    		break;
    	case R.id.menuItem5:
			this.m_sudokuGame.pushBoard();
    		doAll();
    		break;
    	}
    	return super.onOptionsItemSelected(item);
    }

    /** [�Z�[�u]���� */
    private void saveGame() throws IOException {
    	// �X�g���[�����J��
    	FileOutputStream output = this.openFileOutput("sudoku.dat", MODE_PRIVATE);
    	
    	// ���Ƃ̏�Ԃ���������
    	for (int row = 0; row < this.m_sudokuGame.getBoard().blockCellCount(); row++) {
    		for (int col = 0; col < this.m_sudokuGame.getBoard().blockCellCount(); col++) {
    			if (!(row == 0 && col == 0)) {
    				output.write(",".getBytes());
    			}
    			output.write(Integer.toString(this.m_sudokuGame.getBoard().getCell(row, col).getNumber()).getBytes());
    		}
    	}
    	
    	// �X�g���[�������
    	output.close();
    }
    
    /** [���[�h]���� */
    private void loadGame() throws IOException {
    	// �X�g���[�����J��
    	FileInputStream input = this.openFileInput("sudoku.dat");
    	
    	// �Ǎ���
    	BufferedReader reader = new BufferedReader(new InputStreamReader(input));
    	String line = reader.readLine();
    	reader.close();
    	
    	this.m_sudokuGame.init();
    	String[] nums = line.split(",");
    	for (int i = 0; i < nums.length; i++) {
    		int row = i / 9;
    		int col = i % 9;
    		this.m_sudokuGame.getBoard().fixNumber(row, col, Integer.parseInt(nums[i]));
    	}
		this.drawAll();
    }

    /**
     * �Q�[���I�����`�F�b�N���ĕ\���B
     * @param notOver �N���A���Ă��Ȃ��������b�Z�[�W��\������Ƃ��́Atrue�ɂ���B
     */
    private void gameOver(boolean notOver) {
    	String msg = "";
    	if (this.m_sudokuGame.getBoard().isFinished()) {
			msg = "�N���A";
    	} else if (this.m_sudokuGame.getBoard().isFailed()) {
    		msg = "��l�܂�";
    	} else if (notOver) {
    		msg = "�N���A�ł��܂���";
    	}
    	if (msg.length() > 0) {
	    	// �_�C�A���O���b�Z�[�W�\��
			AlertDialog.Builder builder = new AlertDialog.Builder(this);
			builder.setTitle("���ƃT�|�[�g");
			builder.setMessage(msg);
			builder.setPositiveButton("OK", null);
			builder.show();
    	}
    }
    
    /** [����]���� */
    private void doAll() {
    	// [����]���߂̏�����S�͎��s
    	while (m_sudokuGame.parse00() ||
    		   m_sudokuGame.parse01() ||
    		   m_sudokuGame.parse02() ||
    		   m_sudokuGame.parse03() ||
    		   m_sudokuGame.parse12() ||
    		   m_sudokuGame.parse30()) {
    		;
    	}
    	
    	this.drawAll();	// ��ʍĕ`��
    	this.gameOver(true);
    }

    /** ���Ɖ�ʕ\�� */
	private void drawAll() {
		for (int row = 0; row < 9; row++) {
			for (int col = 0; col < 9; col++) {
				TextView elem = (TextView) this.findViewById(m_id.get(row * 9 + col));
				
				int num = this.m_sudokuGame.getBoard().getCell(row, col).getNumber();
				if (num == 0) {
					if (row == 0 && col == 0) {
						Log.d("SS", "unfixed cell");
					}
					// ���m��Z���̕`��
					String text = "";
					ArrayList<Integer> candidates = this.m_sudokuGame.getBoard().getCell(row, col).getCandidates();
					switch (candidates.size()) {
					case 0:
						text = "�~";
						elem.setTextAppearance(this, android.R.style.TextAppearance_Large);
						break;
					case 1:
						text = Integer.toString(candidates.get(0));
						elem.setTextAppearance(this, android.R.style.TextAppearance_Large);
						break;
					case 2:
						for (int i = 0; i < candidates.size(); i++) {
							text += Integer.toString(candidates.get(i));
						}
						elem.setTextAppearance(this, android.R.style.TextAppearance_Small);
						break;
					default:
						text = "+";
						elem.setTextAppearance(this, android.R.style.TextAppearance_Large);
					}
					elem.setText(text);
					elem.setTextColor(Color.DKGRAY);
				} else {
					if (row == 0 && col == 0) {
						Log.d("SS", "fixed cell");
					}
					// �m��Z���̕`��
					elem.setTextAppearance(this, android.R.style.TextAppearance_Large);
					elem.setText(Integer.toString(num));
					elem.setTextColor(Color.WHITE);
				}
			}
		}
	}

	/**
	 * ��ʂ��N���b�N�����Ƃ��̏���
	 * @param v
	 */
	public void onClickRnCn(View v) {
		v.setEnabled(false);

		Log.d("SS", "onClickRnCn enter");

    	String[] contents = v.getContentDescription().toString().split(",");

		final int row = Integer.valueOf(contents[0]);
		final int col = Integer.valueOf(contents[1]);
		
		if (this.m_sudokuGame.getBoard().getCell(row - 1, col - 1).getNumber() == 0) {
			if (this.m_sudokuGame.getBoard().getCell(row - 1, col - 1).getCandidates().size() == 0) {
				// ��₪����Ȃ���ԂȂ̂ŉ������Ȃ��B
				v.setEnabled(true);
				return;
			}
			final String[] items = this.m_sudokuGame.getBoard()
					.getCell(row - 1, col - 1).getCandidates().toString().replaceAll(" |\\[|\\]", "").split(",");
			
			if (items.length == 1) {
				// ��₪��̎��́A���ڊm��
				this.m_sudokuGame.pushBoard();
				this.m_sudokuGame.getBoard().fixNumber(row-1, col-1, Integer.parseInt(items[0]));
				this.drawAll();
				this.gameOver(false);
			} else {
				// ���l�I�����X�g�_�C�A���O��\��
				AlertDialog.Builder builder = new AlertDialog.Builder(this);
				builder.setIcon(R.drawable.ic_launcher);
				builder.setTitle("���l�I��");
				builder.setItems(items, new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int which) {
						Log.d("SS", "onClick(" + row + "," + col + ")");
						Log.d("SS", "value = " + Integer.parseInt(items[which]));
						SudokuSupportActivity.this.m_sudokuGame.pushBoard();
						SudokuSupportActivity.this.m_sudokuGame
							.getBoard().fixNumber(row - 1, col - 1, Integer.parseInt(items[which]));
						SudokuSupportActivity.this.drawAll();
						SudokuSupportActivity.this.gameOver(false);
					}
				});
				builder.show();
			}
		}
		v.setEnabled(true);
	}
}
