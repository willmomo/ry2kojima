// stdafx.h : Include-Datei f�r Standard-System-Include-Dateien,
//  oder projektspezifische Include-Dateien, die h�ufig benutzt, aber
//      in unregelm��igen Abst�nden ge�ndert werden.
//

#if !defined(AFX_STDAFX_H__DE772E71_3A32_4640_A9F3_0798548018DA__INCLUDED_)
#define AFX_STDAFX_H__DE772E71_3A32_4640_A9F3_0798548018DA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define _WIN32_WINNT 0x0400

#include <windows.h>
#include <tchar.h>
#include <stdio.h>

#define MY_ENCRYPT CALG_RC4

// ZU ERLEDIGEN: Verweisen Sie hier auf zus�tzliche Header-Dateien, die Ihr Programm ben�tigt

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt zus�tzliche Deklarationen unmittelbar vor der vorherigen Zeile ein.

#endif // !defined(AFX_STDAFX_H__DE772E71_3A32_4640_A9F3_0798548018DA__INCLUDED_)
