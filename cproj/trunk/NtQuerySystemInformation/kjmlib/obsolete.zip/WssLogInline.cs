﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.IO;
using System.Threading;
using System.Reflection;

namespace kjm {
	#region WssLog definition
	class WssLog {


		[DllImport("KERNEL32.DLL")]
		private static extern uint GetPrivateProfileString(string lpAppName, string lpKeyName, string lpDefault, StringBuilder lpReturnedString, uint nSize, string lpFileName);

		/// <summary>
		/// GetPrivateProfileString を C# に適した形にしたもの
		/// </summary>
		/// <param name="secName"></param>
		/// <param name="keyName"></param>
		/// <param name="defValue"></param>
		/// <param name="iniName"></param>
		/// <returns></returns>
		private static string GetIniString(string secName, string keyName, string defValue, string iniName) {
			StringBuilder buf = new StringBuilder(1024);
			GetPrivateProfileString(secName, keyName, defValue, buf, (uint)buf.Capacity, iniName);
			return buf.ToString();
		}

		[DllImport("KERNEL32.DLL")]
		private static extern uint GetPrivateProfileInt(string lpAppName, string lpKeyName, int nDefault, string lpFileName);

		private static string s_appName;	// アプリケーションの名前(実行ファイル名の拡張子抜き)
		private static string s_basePath;	// アプリケーションの場所

		private static string s_logPath;
		private static int s_logLevel;
		private static int s_logNameType;	// 0 = YYYYMMDD.log , 1 = YYYYMMDD_HH.log
		private static int s_saveDays;
		private static Mutex s_logMutex;

		/// <summary>
		/// アプリケーションの名前(s_appName)と場所(s_basePath)を確定する。
		/// </summary>
		private static void FixIniPath() {
			// モジュールのフルパスを取得する。 
			string work = Assembly.GetExecutingAssembly().GetModules(false)[0].FullyQualifiedName;

			// 実行ファイル名を取得する
			s_appName = Path.GetFileNameWithoutExtension(work);

			// 実行ファイルのパス名を取得する
			s_basePath = Path.GetDirectoryName(work);
		}

		/// <summary>
		/// 各種INIファイルから設定を読み込む
		/// </summary>
		private static void GetIniFile() {
			// WinSousa.iniをセットする。
			string iniName = Path.Combine(s_basePath, "WinSousa.ini");

			// モジュール名.ini に LogPath の記述がある場合、そちらを優先する
			string logPath = GetIniString("WssLog", "LogPath", "", Path.Combine(s_basePath, s_appName + ".ini"));
			if (logPath == "") {
				// 古い設定からログPATHの取得
				logPath = GetIniString("Log", "LogPath", "", iniName);	// 一番最初の s_logPath 候補
				if (logPath == "") {
					logPath = GetIniString("Pathinf", "LogPath", "Log", iniName);	// 二番目の s_logPath 候補
				}
			}
			s_logPath = Path.Combine(s_basePath, logPath);	// フルパスにして設定

			// ログファイル名の形
			s_logNameType = (int)GetPrivateProfileInt("Log", "LogNameType", 1, iniName);

			// LogLevelの取得
			s_logLevel = (int)GetPrivateProfileInt("Log", "LogLevel", 2, iniName);

			// 保存日数の取得
			s_saveDays = (int)GetPrivateProfileInt("Log", "SaveDays", 90, iniName);
		}
		
		/// <summary>
		/// 静的コンストラクタ
		/// </summary>
		static WssLog() {
			FixIniPath();
			GetIniFile();

			// ミューテックス名を作成 "mtx_" + m_BasePath (C:\temp\temp.exe → mtx_C:/temp/)
			s_logMutex = new Mutex(false, "mtx_" + s_basePath.Replace('\\', '/'));
		}

		/// <summary>
		/// このログシステムの名前を返す
		/// </summary>
		/// <param name="buf"></param>
		/// <param name="size"></param>
		public static void WLGetMyName(StringBuilder buf, int size) {
			buf.Clear().Append("inline WssLog system by kjm");
		}

		/// <summary>
		/// 現在のログレベルを取得
		/// </summary>
		/// <returns></returns>
		public static int WLGetLogLevel() {
			int nWork = 0;
			Interlocked.Exchange(ref nWork, s_logLevel);
			return nWork;
		}

		/// <summary>
		/// 新しいログレベルを設定
		/// </summary>
		/// <param name="nNewLogLevel"></param>
		public static void WLSetLogLevel(int nNewLogLevel) {
			if (nNewLogLevel < LOGLV_DEBUG || nNewLogLevel > LOGLV_FATALERR)
				return;
			System.Threading.Interlocked.Exchange(ref s_logLevel, nNewLogLevel);
		}

		/// <summary>
		/// 現在のログパスを取得
		/// </summary>
		/// <param name="pszBuffer"></param>
		/// <param name="nSize"></param>
		public static void WLGetLogPath(StringBuilder pszBuffer, int nSize) {
			pszBuffer.Clear().Append(s_logPath);
		}

		/// <summary>
		/// 新しいログパスを設定
		/// </summary>
		/// <param name="newPath"></param>
		public static void WLSetLogPath(string newPath) {
			s_logPath = newPath;
		}

		/// <summary>
		/// 現在のログ名タイプを取得
		/// </summary>
		/// <returns></returns>
		public static int WLGetLogNameType() {
			return s_logNameType;
		}

		/// <summary>
		/// 新しいログ名タイプを設定
		/// </summary>
		/// <param name="nNameType"></param>
		public static void WLSetLogNameType(int nNameType) {
			s_logNameType = nNameType;
		}

		/// <summary>
		/// 通常ログ出力
		/// </summary>
		/// <param name="ident"></param>
		/// <param name="loglevel"></param>
		/// <param name="msg"></param>
		private static void Winssa_Log(string ident, int loglevel, string msg) {
			// 要求ログレベルが低い時は何もしない
			if (loglevel != LOGLV_ALWAYS && loglevel < s_logLevel) {
				return;
			}

			DateTime ptm = DateTime.Now;

			string buf = string.Format("{0:HH}:{0:mm}:{0:ss}.{0:fff} [{1,-6}]{4}{2:X4}:{3:X4}{5}:",
				ptm, ident,
				System.Diagnostics.Process.GetCurrentProcess().Id,
				System.Threading.Thread.CurrentThread.ManagedThreadId,
				"{", "}");

			string path = Path.Combine(s_logPath, string.Format("{0:yyyy}{0:MM}{0:dd}", ptm));

			if (s_logMutex.WaitOne(3000)) {
				try {
					System.IO.Directory.CreateDirectory(path);

					//　ログファイル名を作成
					string logfname = string.Format((s_logNameType == 1 ? "{0:yyyy}{0:MM}{0:dd}_{0:HH}.log" : "{0:yyyy}{0:MM}{0:dd}.log"), ptm);

					using (FileStream stream = new FileStream(Path.Combine(path, logfname), FileMode.Append, FileAccess.Write, FileShare.Read)) {
						using (StreamWriter writer = new StreamWriter(stream)) {
							writer.Write(buf);
							writer.WriteLine(msg);
						}
					}
				} catch(Exception ex) {
					// ログシステム異常！イベントログに書きたいところ
				}

				s_logMutex.ReleaseMutex();
			}
		}

		/// <summary>
		/// VBログ出力
		/// </summary>
		/// <param name="ident"></param>
		/// <param name="loglevel"></param>
		/// <param name="msg"></param>
		public static void WinssaVB_Log(string ident, int loglevel, string msg) {
			Winssa_Log(ident, loglevel, msg);
		}

		/// <summary>
		/// 現在の保存日数の取得
		/// </summary>
		/// <returns></returns>
		public static int WLGetSaveDays() {
			return s_saveDays;
		}

		/// <summary>
		/// 新しい保存日数の設定
		/// </summary>
		/// <param name="newValue"></param>
		public static void WLSetSaveDays(int newValue) {
			s_saveDays = newValue;
		}

		/// <summary>
		/// 保存日付の取得
		/// </summary>
		/// <returns></returns>
		private static int GetSaveDate() {
			// システム時刻を得ます。
			DateTime lNow = DateTime.Now.AddDays(-(s_saveDays + 1));
			return (lNow.Year * 10000) + (lNow.Month * 100) + lNow.Day;
		}

		/// <summary>
		/// 古いログの削除
		/// </summary>
		public static void WLDeleteOldLog() {
			Winssa_Log("WSSLOG", LOGLV_INFO, string.Format("<{0}> WLDeleteOldLog() enter.", s_appName));

			// 保存日付の取得
			int cSaveDate = GetSaveDate();
			Winssa_Log("WSSLOG", LOGLV_INFO, string.Format("<{0}> WLDeleteOldLog(): '{1}' より古い日付フォルダを削除します(保存日数 {2})。", s_appName, cSaveDate, s_saveDays));

			// ログフォルダを検索するワイルドカードを用意
			Winssa_Log("WSSLOG", LOGLV_INFO, string.Format("<{0}> WLDeleteOldLog(): '{1}' を検索します。", s_appName, s_logPath));

			// ログフォルダを列挙
			foreach (string oneDir in System.IO.Directory.GetDirectories(s_logPath)) {
				string cFileName = System.IO.Path.GetFileNameWithoutExtension(oneDir);

				int nFileName = 0;
				if (Int32.TryParse(cFileName, out nFileName)) {
					if (nFileName <= cSaveDate) {
						Winssa_Log("WSSLOG", LOGLV_INFO, string.Format("<{0}> WLDeleteOldLog(): フォルダ '{1}' を削除します。", s_appName, oneDir));

						try {
							System.IO.Directory.Delete(oneDir, true);
						} catch (Exception ex) {
							Winssa_Log("WSSLOG", LOGLV_ERR, string.Format("<{0}> WLDeleteOldLog(): error {1} : フォルダの削除に失敗しました。", s_appName, ex.Message));
						}
					}
				}
			}

			Winssa_Log("WSSLOG", LOGLV_INFO, string.Format("<{0}> WLDeleteOldLog() leave.", s_appName));
		}

		public const int LOGLV_DEBUG = 0;			// デバッグ用
		public const int LOGLV_TRACE = 1;			// トレース
		public const int LOGLV_WARNING = 2;			// ワーニング(通常はこのレベル以上を出力)
		public const int LOGLV_ERR = 3;			    // エラー
		public const int LOGLV_FATALERR = 4;		// 致命的エラー
		public const int LOGLV_INFO = 5;			// 情報
		public const int LOGLV_ALWAYS = 9;			// 必ずログを出す
	}
	#endregion
}
