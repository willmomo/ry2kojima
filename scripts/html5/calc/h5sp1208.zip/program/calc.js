// calc.js
// 変数の初期化
var buttons = [
  'C', '/', '*', 'BS',
  '7', '8', '9', 'R',
  '4', '5', '6', '%',
  '1', '2', '3', '-',
  '0', '.', '+', '='
];
// 画面の初期化
window.onload = function() {
  createButtons();
  // キャッシュを更新するか確認
  var appCache = window.applicationCache;
  if (window.navigator.onLine) appCache.update();
  appCache.addEventListener(
    'updateready', function(e) {
      if (confirm('最新版にアップデートしますか?')) {
        appCache.swapCache();
        window.location.reload();
      }
    });
};
// 電卓のボタンを動的に生成する
function createButtons() {
  var div = $("#buttons");
  for (var i = 0; i < buttons.length; i++) {
    var ch = buttons[i];
    var btn = document.createElement("button");
    btn.innerHTML = ch;
    btn.style.width  = (80 - 4 * 2) + "px";
    btn.style.height = "60px";
    btn.style.fontSize = "32px";
    btn.className = "calcButton";
    btn.onclick = calcButton_clickHandler;
    div.appendChild(btn);
  }
}
// 電卓のボタンを押した時のイベント
function calcButton_clickHandler(e) {
  e.preventDefault();
  // 現在ディスプレイに表示されている文字を取得
  var disp = $("#disp").value;
  if (disp == "0") { // "0"だけならリセット
    $("#disp").value = "";
  }
  // 押されたボタンに書かれている文字を取得
  var ch = e.target.innerHTML;
  // 数字か計算記号ならそのまま追加する
  var numflag = "01234567890+-*/%.";
  if (numflag.indexOf(ch) >= 0) {
    $("#disp").value += ch;
  }
  // [=]ボタンなら計算結果を表示
  else if (ch == "=") {
    try {
      var v = eval('(' + disp + ')');
      $("#disp").value = v;
    } catch (e) {
      alert("[ERROR] " + e.message);
    }
  }
  // [C]ボタンなら表示をクリア
  else if (ch == "C") {
    $("#disp").value = "0";
  }
  // [BS]ボタンなら一文字消す
  else if (ch == "BS") {
    var v = disp.substr(0, disp.length - 1);
    if (v == "") v = "0";
    $("#disp").value = v;
  }
  // [R]ボタンならWeb APIをチェック
  else if (ch == "R") {
    json_getRate();
  }
}
// Web APIを使ってレートをチェックする
function json_getRate() {
  var apiurl = "http://api.aoikujira.com/kawase/get.php?" +
               "code=usd&format=jsonp2&callback=kawaseResult"
  jsonp(apiurl);
}
// JSONPにより呼ばれるコールバック関数
function kawaseResult(res) {
  // 日本円(JPY)を取り出す
  var usd_jpy = parseFloat(res["JPY"]);
  try {
    // 現在の計算式を処理する
    var v = eval($("#disp").value);
    // 米ドルを日本円に変換し表示する
    v = v * usd_jpy;
    $("#disp").value = v;
  } catch (e) {
    alert('[ERROR]' + e.message);
  }
}
// ---------------------------------------------------------
// DOM要素を一つ選択する
function $(query) {
  return document.querySelector(query);
}
// JSONPを利用する
function jsonp(url) {
  var script = document.createElement("script");
  script.src = url;
  document.body.appendChild(script);
}


