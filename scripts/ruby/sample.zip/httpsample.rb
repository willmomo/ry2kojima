$KCODE = 'sjis'

require 'net/http'

#------------------------------------------------------------------------------
# GET���ĕ\�����邾��
#------------------------------------------------------------------------------
def ex1()
	Net::HTTP.get_print '192.168.120.214', '/dev/default.asp'
end

#------------------------------------------------------------------------------
# URI���g��
#------------------------------------------------------------------------------
def ex2()
	Net::HTTP.get_print URI.parse('http://192.168.120.214/dev/default.asp')
end

#------------------------------------------------------------------------------
# ���ėp�I�ȗ�
#------------------------------------------------------------------------------
def ex3()
	url = URI.parse('http://192.168.120.214/dev/default.asp')
	res = Net::HTTP.start(url.host, url.port) {|http|
		http.get('/dev/default.asp')
	}
	puts res.body
end

#------------------------------------------------------------------------------
# ��̗��肳��ɔėp�I�ȗ�
#------------------------------------------------------------------------------
def ex4()
	url = URI.parse('http://192.168.120.214/dev/default.asp')
	req = Net::HTTP::Get.new(url.path)
	res = Net::HTTP::start(url.host, url.port) {|http|
		http.request(req)
	}
	puts res.body
end

#------------------------------------------------------------------------------
# proxy�o�R
#------------------------------------------------------------------------------
def pxex(uri)
#	url = URI.parse('http://www.yahoo.co.jp/index.html')
#	res = Net::HTTP::Proxy('sanko-net.securewg.jp', 8080, 'ry2kojima', 'ota7Yoda').start(url.host, url.port) {|http|
#		http.get('/index.html')
#	}
#	puts res.body

	proxy_serv = nil
	proxy_port = nil
	#proxy_serv = 'sanko-net.securewg.jp'
	#proxy_port = 8080
	url = URI.parse(uri)
	req = Net::HTTP::Get.new(url.path)
	res = Net::HTTP::Proxy(proxy_serv, proxy_port, 'ry2kojima', 'ota7Yoda').start(url.host, url.port) {|http|
		http.request(req)
	}
	puts res.body
end

def ex5()
	uri = 'http://papimo.exabyte.co.jp/hallman/PHP/manage/uploadDataZip.php'
	url = URI.parse(uri)
	req = Net::HTTP::Get.new(url.path)
	res = Net::HTTP.start(url.host, url.port) {|http|

		request = Net::HTTP::Post.new(url.path)

		#�w�b�_�[��
		request["user-agent"] = "Ruby/#{RUBY_VERSION} MyHttpClient"
		request.set_content_type("multipart/form-data; boundary=myboundary")
		#�i�ȉ��ł��j
		#request["content-type"] = "multipart/form-data; boundary=myboundary"

		#�{�f�B��
		#multipart/form-data�̎d�l�ɂ��킹��body���쐬
		body = ""
		body.concat("--myboundary\r\n")
		body.concat("content-disposition: form-data; name=\"COMPANYID\";\r\n")
		body.concat("\r\n")
		body.concat("1\r\n")

		body.concat("--myboundary\r\n")
		body.concat("content-disposition: form-data; name=\"TENPOID\";\r\n")
		body.concat("\r\n")
		body.concat("2\r\n")

		body.concat("--myboundary\r\n")
		body.concat("content-disposition: form-data; name=\"PASSWORD\";\r\n")
		body.concat("\r\n")
		body.concat("3\r\n")

		body.concat("--myboundary\r\n")
		body.concat("content-disposition: form-data; name=\"GMCZIPFILE\"; filename=\"sample.zip\"\r\n")
		body.concat("\r\n")
		File::open("sample.zip"){|f| body.concat(f.read + "\r\n") }

		body.concat("--myboundary--\r\n")
		request.body = body

		#���M
		response = http.request(request)

		p response
	}
	#puts res.body
end

#------------------------------------------------------------------------------


#ex1()
#ex2()
#ex3()
#ex4()

#pxex('https://www.google.co.jp/webhp?sourceid=chrome-instant&ie=UTF-8&ion=1#hl=ja&sclient=psy-ab&q=filesystemobject%20deletefolder&oq=&gs_l=&pbx=1&fp=88cdafd03c6e7baf&ion=1&bav=on.2,or.r_gc.r_pw.r_cp.r_qf.,cf.osb&biw=1315&bih=880')

ex5()
